<?php
	include "connect.php";

	//echo "You are here, you have a quiz?";

	$roll = $_POST["txtRollNo"];
	$name = $_POST["txtName"];
	$email = $_POST["txtemail"];
	$semester = $_POST["semester"];
	$chose_event=$_POST["event"];

	$qry = "INSERT INTO Register VALUES('".$roll."' , '".$name."' , '".$email."', '".$semester."', '".$chose_event."')";

	//echo $qry;
	if ($con->query($qry)) {
		$msg = "Student Registered";
	}
	else
		$msg = "Error!";

	header("Location:register.php?Message=$msg")
?>