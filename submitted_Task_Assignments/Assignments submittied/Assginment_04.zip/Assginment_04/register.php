<?php
	include "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student's Registeration</title>
</head>
<body>
	<form action="register_try.php" method="post">
		<table align="center">
			<th colspan="2">Nutect' 2 Event Registration fro Fastian </th>
			<tr>
				<td>
					Roll No
				</td>
				<td>
					<input type="text" name="txtRollNo" required>
				</td>
			</tr>
			<tr>
				<td>
					Name
				</td>
				<td>
					<input type="text" name="txtName" required>
				</td>
			</tr>
			<tr>
				<td>
					email
				</td>
				<td>
					<input type="text" name="txtemail" required>
				</td>
			</tr>
			<tr>
				<td>
					Semester
				</td>
				<td>
					<select   name="semester" required>
						<option name="computer_science">Computer Science</option>
						<option name="electrical">electrical</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					chose Event
				</td>
				<td>
					<select name="event" required> 
					<option name="programming"> Programming</option>
					<option name="Gaming">Gaming</option>
				</td>
			</tr>


			<tr>
				<td colspan="2" align="right">
					<input type="submit" value="submit">
				</td>
			</tr>

			<tr>


				<td colspan="2">
					<?php
						if (isset($_GET["Message"])) {
							echo $_GET["Message"];
						}
					?>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>