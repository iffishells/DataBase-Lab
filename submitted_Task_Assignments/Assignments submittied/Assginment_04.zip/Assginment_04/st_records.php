
<?php
	include "connect.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Student's Record</title>
</head>
<body>
	<form action="" method="post">
		<table align="center">
			<th colspan="2">Search Type</th>
			<tr>
				<td>
					Search 
				</td>
				<td>
					<select name="selection" required>
						<option value="roll_no">rollno</option>
						<option value="semester">department</option>
						<option value="chose_event">event</option>
					</select>
				</td>
			</tr>

			<tr>
				<td>
					Search
				</td>
				<td>
					<input type="text" name="txtsearch" required>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">
					<input type="submit"  name="submit" value="Search">
				</td>
			</tr>
		</table>
	</form>
	<?php
		if (isset($_POST["txtsearch"])) {
			echo "Hellow bheta";
			$Search = $_POST["txtsearch"];
			$option = $_POST["selection"];
			$qry = "";

			if($option == "roll_no") {
				$qry = "SELECT * FROM Register WHERE roll_no = '".$Search."'";
			}
			if($option == "semester") {
				$qry = "SELECT * FROM reg_Register WHERE semester like  '%".$Search."%'" ;
			}
			if($option == "chose_event") {
				$qry = "SELECT * FROM Register WHERE chose_event like  '%".$Search."%'";
			}

			$res = $con->query($qry);
			$result = "";

			if ($res->num_rows>0) {
				$result .= "<table align='center'>";
				$result .= "<th>Roll No</th><th>Name</th><th>Email</th><th>department</th><th>Event</th>";
				while ($row = $res->fetch_assoc()) 
				{
					//one row
					$result .= "<tr>
									<td>
										".$row['rollno']."
									</td>
									<td>
										".$row['name']."
									</td>
									<td>
										".$row['email']."
									</td>
									<td>
										".$row['semester']."
									</td>
									<td>
										".$row['chose_event']."
									</td>
								</tr>";
				}
				$result .= "</table>";
			}
			else {
				echo "This input doesn't exist in database";
			}
			echo $result;
		}
	?>
</body>
</html>

