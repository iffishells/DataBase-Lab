drop database if EXISTS person;

create database person1;

create table users(
	users_id int primary key,
	username varchar(30) Not NULL,
	password varchar(30) Not NULL,
	email varchar(40) Not NULL
);

create table summary(
	id int Not NULL primary key,
	total_users int Not NULL,
	Yahoo int Not NULL,
	Hotmail int Not NULL,
	Gmail int Not NULL
	);



###############################################################
#Question 01
##EXAMPLE:...
delimiter $$
 create procedure insertion_summary( IN id INT,total_users int ,Yahoo int ,Hotmail int , Gmail int)
 	begin
 		insert into summary
			values(id,total_users,Yahoo,Hotmail,Gmail);
 	END $$
delimiter ;
CALL insertion_summary(1,2,1,0,1);
CALL insertion_summary(2,3,1,1,1);
CALL insertion_summary(3,4,2,2,0);
CALL insertion_summary(4,5,1,1,3);
CALL insertion_summary(5,6,2,2,2);
CALL insertion_summary(6,15,5,5,5);
delimiter ; 


##Question02
delimiter $$
 create procedure insertion_User_Data( IN users_id INT,username varchar(30) ,password varchar(30) ,email varchar(30) )
 	begin
 		insert into users
			values(users_id,username,password,email);
 	END $$

 delimiter ;

 CALL insertion_User_Data(1,"ift123","ift321","ift123@yahoo.com");
 CALL insertion_User_Data(2,"zain123","zain321","zain789@Gmail.com");
 CALL insertion_User_Data(3,"Ali123","Ali321","Ali123@Hotmail.com");
 CALL insertion_User_Data(4,"ammar123","ammaar321","ammar789@Hotmail.com");
 CALL insertion_User_Data(5,"iftikhar123","iftikhar321","iftikhar123@yahoo.com");
 CALL insertion_User_Data(6,"Sana123","Sana321","sana789@Gmail.com");
 CALL insertion_User_Data(7,"khan123","khan321","khan789@Gmail.com");
 CALL insertion_User_Data(8,"momina123","momina321","momina789@Gmail.com");
 CALL insertion_User_Data(9,"asad123","asad321","asad789@Gmail.com");
 CALL insertion_User_Data(10,"aimen123","aimen321","aimen789@Gmail.com");
 delimiter ;
 #Question03

delimiter $$

  create procedure insertion_summary( IN id INT,total_users int ,Yahoo int ,Hotmail int ,Gmail int )
 	begin
 		insert into summary
			values(id,total_users,Yahoo,Hotmail,Gmail);
 	END $$

 delimiter ;

 CALL insertion_summary(1,2,1,0,1);
 delimiter ;
 #Question03



---------------------------------------------------------
delimiter $$
create procedure user_count( OUT count_users int , out gmail_users int, out yahoo_users int ,out Hotmail_users int)
	begin

	select count(users_id) into count_users from users;

	select count(users_id) into gmail_users from users
	where email like "%gmail.com";

	select count(users_id) into yahoo_users from users
	where email like "%yahoo.com";

	select count(users_id) into Hotmail_users from users
	where email like "%Hotmail.com";

	end $$

delimiter ;


----------------------------------------------------------------------------
delimiter $$

create trigger update_summary_insert 
	after insert on users

	for each row
	begin
	declare count_users int;
	declare yahoo_users int;
	declare gmail_users int;
	declare Hotmail_users int;

	CALL user_count(count_users ,gmail_users,yahoo_users,Hotmail_users);
	update summary
		set total_users=count_users,
		Hotmail = Hotmail_users,
		gmail = gmail_users,
		yahoo = yahoo_users

		limit 1;

	END$$

delimiter ;
-----------------------------------------------------------------

delimiter $$

create trigger update_summary_update 
	after update on users

	for each row
	begin
	declare count_users int;
	declare yahoo_users int;
	declare gmail_users int;
	declare Hotmail_users int;

	CALL user_count(count_users ,gmail_users,yahoo_users,Hotmail_users);
	update summary
		set total_users=count_users,
		Hotmail = Hotmail_users,
		gmail = gmail_users,
		yahoo = yahoo_users

		limit 1;

	END$$

delimiter ;
----------------------------------------------------------------------------
delimiter $$

create trigger update_summary_delete 
	after delete on users

	for each row
	begin
	declare count_users int;
	declare yahoo_users int;
	declare gmail_users int;
	declare Hotmail_users int;

	CALL user_count(count_users ,gmail_users,yahoo_users,Hotmail_users);
	update summary
		set total_users=count_users,
		Hotmail = Hotmail_users,
		gmail = gmail_users,
		yahoo = yahoo_users

		limit 1;

	END$$

delimiter ;