drop database if EXISTS person;

create database person;

create table users(
	users_id int primary key,
	username varchar(30) Not NULL,
	password varchar(30) Not NULL,
	email varchar(40) Not NULL
);

create table summary(
	id int Not NULL primary key,
	total_users int Not NULL,
	Yahoo int Not NULL,
	Hotmail int Not NULL,
	Gmail int Not NULL
	);



###############################################################
#Question 01
##EXAMPLE:...
delimiter $$
 create procedure insertion_summary( IN id INT,total_users int ,Yahoo int ,Hotmail int , Gmail int)
 	begin
 		insert into summary
			values(id,total_users,Yahoo,Hotmail,Gmail);
 	END $$
delimiter ;
CALL insertion_summary(1,2,1,0,1);
CALL insertion_summary(2,3,1,1,1);
CALL insertion_summary(3,4,2,2,0);
CALL insertion_summary(4,5,1,1,3);
CALL insertion_summary(5,6,2,2,2);
CALL insertion_summary(6,15,5,5,5);
delimiter ; 


##Question02
delimiter $$
 create procedure insertion_User_Data( IN users_id INT,username varchar(30) ,password varchar(30) ,email varchar(30) )
 	begin
 		insert into users
			values(users_id,username,password,email);
 	END $$

 delimiter ;

 CALL insertion_User_Data(1,"abc123","def321","abc123@yahoo.com");
 CALL insertion_User_Data(2,"xyz123","vbn321","xyz789@Gmail.com");
 CALL insertion_User_Data(3,"gef123","def321","gef123@Hotmail.com");
 CALL insertion_User_Data(4,"mno123","vbn321","mno789@Hotmail.com");
 CALL insertion_User_Data(5,"pqr123","def321","pwr123@yahoo.com");
 CALL insertion_User_Data(6,"pwr123","vbn321","pwr789@Gmail.com");
 delimiter ;
 #Question03

 
 delimiter $$
create procedure AVG_yahoo()
	begin
		select avg(Yahoo) from summary;
	END $$
delimiter ;

call AVG_yahoo();


#Question04
 delimiter $$
create procedure Min_Gamail()
	begin
		select min(Gmail) from summary;
	END $$
delimiter ;

call Min_Gamail();


#Question05
 delimiter $$
create procedure Max_Hotmail()
	begin
		select max(Hotmail) from summary;
	END $$
delimiter ;

call Max_Hotmail();


#Question06

delimiter $$
create procedure update_total_user()
	begin
update summary
	set total_users=1
	where Yahoo <= Hotmail;


	END $$

delimiter ;
call update_total_user();